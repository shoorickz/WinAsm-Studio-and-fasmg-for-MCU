ez80.inc was taken from https://github.com/jacobly0/fasmg-ez80
refer to http://board.flatassembler.net/topic.php?t=19201 also